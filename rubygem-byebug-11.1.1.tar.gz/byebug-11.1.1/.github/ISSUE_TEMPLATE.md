## Problem description

Replace this text with a description of the problem you're having. Make
sure that you're running the latest stable release of both byebug and ruby and
that the problem you're reporting hasn't been reported (and potentially fixed)
already.

## Expected behavior

Describe here how you expected byebug to behave in this particular situation.

## Actual behavior

Describe here what actually happened.

## Steps to reproduce the problem

This is extremely important! Providing us with a reliable way to reproduce
a problem will expedite its solution.
